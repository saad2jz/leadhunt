# Socle de quotas API — Firebase Functions

Le backend maintient un compteur mensuel Firestore dans
`/apiUsage/{apiName}` pour `hunter`, `apollo` et `pappers`.

Chaque appel payant passe par `apiQuota.reserve(apiName)` avant l'appel HTTP.
La réservation est atomique grâce à une transaction Firestore : deux Functions
concurrentes ne peuvent pas consommer le même dernier crédit. Au changement de
mois UTC, la première réservation remet automatiquement le compteur à zéro.

## Document Firestore

Exemple `/apiUsage/hunter` :

```json
{
  "apiName": "hunter",
  "month": "2026-08",
  "count": 17,
  "limit": 50,
  "remaining": 33,
  "updatedAt": "server timestamp"
}
```

Les règles Firestore interdisent tout accès client à cette collection. Seules
les Cloud Functions via l'Admin SDK peuvent la lire et l'écrire.

## Fallbacks

- Contacts : Hunter est réservé et appelé en premier ; si son quota est atteint
  ou s'il ne trouve rien, Apollo prend la suite.
- Entreprises : Sirene reste toujours la base ; Pappers n'est appelé que si son
  quota est disponible. Sinon, le résultat Sirene est conservé.
- Si le fournisseur signale malgré tout un quota épuisé, l'adaptateur lève
  `ProviderQuotaError`. Le compteur local est marqué épuisé et les prochains
  appels prennent directement le fallback.

## Configuration et vérification

Configurer les valeurs décrites dans `functions/.env.example`, puis lancer :

```bash
cd functions
npm install
npm run check
```

Les limites sont lues depuis l'environnement à chaque réservation. Elles
peuvent donc être alignées sur le forfait fournisseur lors d'un redéploiement.
