# Prospect Intelligence

MVP Firebase d'un outil de prospection B2B : découverte d'entreprises,
décideurs, buyer personas, scoring Fit/Timing, plans d'approche et export CSV.

## Contenu

- `frontend/` : React + Vite, interface responsive et mode sombre.
- `functions/` : Cloud Functions TypeScript strict et validation Zod.
- `firestore.rules` : isolation des recherches par utilisateur.
- `firestore.indexes.json` : index de l'historique.
- `.github/workflows/ci.yml` : tests, builds et déploiement sur `main`.

Sans configuration Firebase, le frontend démarre en mode démonstration avec des
données réalistes. Les fonctions utilisent aussi des données de démonstration
pour la découverte ; les adaptateurs de quotas Hunter, Apollo et Pappers sont
déjà prêts à recevoir les clients HTTP réels.

## Démarrage local

```bash
cd frontend
npm install
npm run dev
```

Dans un second terminal :

```bash
cd functions
npm install
npm run check
```

Pour connecter Firebase, copier `frontend/.env.example` vers `frontend/.env`,
renseigner les valeurs du SDK Web Firebase, puis activer Auth email/mot de passe
et Google dans la console Firebase.

## Variables backend

Les limites mensuelles sont définies dans `functions/.env.example` : Hunter 50,
Apollo 75 et Pappers 100 par défaut. Ajouter `ANTHROPIC_API_KEY` pour activer la
génération réelle ; sans elle, un résultat de démonstration structuré est rendu.

Le document `/apiUsage/{apiName}` est mis à jour dans une transaction avant
chaque appel facturable. Son compteur est automatiquement réinitialisé au
premier appel du nouveau mois UTC. Les clients ne peuvent jamais accéder à
cette collection.

## Déploiement

1. Copier `.firebaserc.example` vers `.firebaserc` et remplacer l'identifiant.
2. Construire les deux packages.
3. Déployer avec Firebase CLI.

La CI attend les secrets GitHub `FIREBASE_PROJECT_ID` et une authentification
Google Cloud adaptée à votre organisation. Pour une CI de production, privilégier
GitHub OIDC / Workload Identity Federation plutôt qu'une clé longue durée.
